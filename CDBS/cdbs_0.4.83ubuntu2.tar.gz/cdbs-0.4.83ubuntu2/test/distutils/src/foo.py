class foo:
  def __init__(self):
    self.name = "JBailey"
    self.id = 555

  def output(self):
    print self.name
    print self.id
